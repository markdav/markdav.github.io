 /*
 
 Add this to the head of the HTML file
 
<meta name="copyright" content="Ã‚Â© Copyright ,  Hewlett Packard Enterprise Development LP">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://h50007.www5.hpe.com/caas-static/js/framework/jquery/v-1-8/can.jquery.js"></script>
<script src="https://h50007.www5.hpe.com/hfws/us/en/hpe/latest.r?contentType=js"></script>
<script src="cstooljavascript.js"></script>
<link rel="stylesheet" type="text/css" href="cstoolstyle.css">
 
 *** DELETE ALL "ENTRY" REFERENCES
 *** DELETE THE TABLE HOVER STYLE
 

*/

        
        
  
<!-- First row (A) -->


                        $(document).ready(function(){
    $('.rA, .csstartingone').hover(function(){
        $('.csstartingone').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingone').css("background-color", "#80746E").css("color", "white");
    });
}); 





<!-- Second row (B) -->
        
                        $(document).ready(function(){
    $('.rB, .csstartingtwo').hover(function(){
        $('.csstartingtwo').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingtwo').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        

        
<!-- Third row (C) -->
        
                        $(document).ready(function(){
    $('.rC, .csstartingthree').hover(function(){
        $('.csstartingthree').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingthree').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        
  

<!-- Fourth row (D) -->
        

$(document).ready(function(){
    $('.rD, .csstartingfour').hover(function(){
        $('.csstartingfour').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingfour').css("background-color", "#80746E").css("color", "white");
    });
}); 


        

<!-- Fifth row (E) -->
        
                        $(document).ready(function(){
    $('.rE, .csstartingfive').hover(function(){
        $('.csstartingfive').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingfive').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
     
        
 <!-- Sixth row (F) -->
        
                        $(document).ready(function(){
    $('.rF, .csstartingsix').hover(function(){
        $('.csstartingsix').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingsix').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
  
        
        <!-- Seven row (G) -->
        
        
$(document).ready(function(){
    $('.rG, .csstartingseven').hover(function(){
        $('.csstartingseven').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingseven').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        
 
        
         <!-- Eight row (H) -->
 
$(document).ready(function(){
    $('.rH, .csstartingeight').hover(function(){
        $('.csstartingeight').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingeight').css("background-color", "#80746E").css("color", "white");
    });
}); 
        

        
         <!-- Nine row (I) -->
        
 $(document).ready(function(){
    $('.rI, .csstartingnine').hover(function(){
        $('.csstartingnine').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingnine').css("background-color", "#80746E").css("color", "white");
    });
}); 
        


         <!-- Tenth row (J) -->

 $(document).ready(function(){
    $('.rJ, .csstartingten').hover(function(){
        $('.csstartingten').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingten').css("background-color", "#80746E").css("color", "white");
    });
}); 
        

        
         <!-- Eleventh row (K) -->
        
 $(document).ready(function(){
    $('.rK, .csstartingeleven').hover(function(){
        $('.csstartingeleven').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingeleven').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        


         <!-- Twelfth row (L) -->

 $(document).ready(function(){
    $('.rL, .csstartingtwelve').hover(function(){
        $('.csstartingtwelve').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingtwelve').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        

        
         <!-- Thirteenth row (M) -->
        

  $(document).ready(function(){
    $('.rM, .csstartingthirteen').hover(function(){
        $('.csstartingthirteen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingthirteen').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        
  $(document).ready(function(){
    $('.rMa, .csstartingfourteen').hover(function(){
        $('.csstartingfourteen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingfourteen').css("background-color", "#80746E").css("color", "white");
    });
}); 

  $(document).ready(function(){
    $('.rNa, .csstartingfifteen').hover(function(){
        $('.csstartingfifteen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingfifteen').css("background-color", "#80746E").css("color", "white");
    });
}); 


  $(document).ready(function(){
    $('.rNb, .csstartingsixteen').hover(function(){
        $('.csstartingsixteen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingsixteen').css("background-color", "#80746E").css("color", "white");
    });
});
     
  $(document).ready(function(){
    $('.rPa, .csstartingseventeen').hover(function(){
        $('.csstartingseventeen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingseventeen').css("background-color", "#80746E").css("color", "white");
    });
});

  $(document).ready(function(){
    $('.rQa, .csstartingeighteen').hover(function(){
        $('.csstartingeighteen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingeighteen').css("background-color", "#80746E").css("color", "white");
    });
});


  $(document).ready(function(){
    $('.rRa, .csstartingnineteen').hover(function(){
        $('.csstartingnineteen').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.csstartingnineteen').css("background-color", "#80746E").css("color", "white");
    });
});
  



 <!-- Thirteenth row (N) Image Streamer first row -->

  $(document).ready(function(){
    $('.rN, .isversionfromone').hover(function(){
        $('.isversionfromone').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromone').css("background-color", "#80746E").css("color", "white");
    });
}); 

   
        

 <!-- Thirteenth row (O) -->

  $(document).ready(function(){
    $('.rO, .isversionfromtwo').hover(function(){
        $('.isversionfromtwo').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromtwo').css("background-color", "#80746E").css("color", "white");
    });
}); 
        


 <!-- Thirteenth row (P) -->

  $(document).ready(function(){
    $('.rP, .isversionfromthree').hover(function(){
        $('.isversionfromthree').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromthree').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        


 <!-- Thirteenth row (Q) -->

  $(document).ready(function(){
    $('.rQ, .isversionfromfour').hover(function(){
        $('.isversionfromfour').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromfour').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        


 <!-- Thirteenth row (R) -->

  $(document).ready(function(){
    $('.rR, .isversionfromfive').hover(function(){
        $('.isversionfromfive').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromfive').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        


 <!-- Thirteenth row (S) -->

  $(document).ready(function(){
    $('.rS, .isversionfromsix').hover(function(){
        $('.isversionfromsix').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromsix').css("background-color", "#80746E").css("color", "white");
    });
}); 
        
        



 <!-- Thirteenth row (T) -->

  $(document).ready(function(){
    $('.rT, .isversionfromseven').hover(function(){
        $('.isversionfromseven').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromseven').css("background-color", "#80746E").css("color", "white");
    });
}); 
        


 <!-- Thirteenth row (U) -->

  $(document).ready(function(){
    $('.rU, .isversionfromeight').hover(function(){
        $('.isversionfromeight').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromeight').css("background-color", "#80746E").css("color", "white");
    });
}); 
        

  $(document).ready(function(){
    $('.rV, .isversionfromnine').hover(function(){
        $('.isversionfromnine').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromnine').css("background-color", "#80746E").css("color", "white");
    });
}); 


  $(document).ready(function(){
    $('.rW, .isversionfromten').hover(function(){
        $('.isversionfromten').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromten').css("background-color", "#80746E").css("color", "white");
    });
}); 


  $(document).ready(function(){
    $('.rX, .isversionfromeleven').hover(function(){
        $('.isversionfromeleven').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromeleven').css("background-color", "#80746E").css("color", "white");
    });
});
       

  $(document).ready(function(){
    $('.rZ, .isversionfromtwelve').hover(function(){
        $('.isversionfromtwelve').css("background-color", "#48413e").css("color", "white");
        }, function(){
        $('.isversionfromtwelve').css("background-color", "#80746E").css("color", "white");
    });
});