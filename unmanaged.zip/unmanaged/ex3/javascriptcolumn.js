 /*
 
 Add this to the head of the HTML file
 
<meta name="copyright" content="Ã‚Â© Copyright ,  Hewlett Packard Enterprise Development LP">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://h50007.www5.hpe.com/caas-static/js/framework/jquery/v-1-8/can.jquery.js"></script>
<script src="https://h50007.www5.hpe.com/hfws/us/en/hpe/latest.r?contentType=js"></script>
<script src="cstooljavascript.js"></script>
<link rel="stylesheet" type="text/css" href="cstoolstyle.css">
 
 *** DELETE ALL "ENTRY" REFERENCES
 *** DELETE THE TABLE HOVER STYLE
 

*/
  
<!-- First column -->
        
                        $(document).ready(function(){
    $('.cA, .csendingone, .isversiontoone').hover(function(){
        $('.csendingone, .isversiontoone').css("background-color", "#252a2e");
        }, function(){
        $('.csendingone, .isversiontoone').css("background-color", "#425563");
    });
}); 

  
        
        

        
  
        
    
<!-- Second column -->
        
                                $(document).ready(function(){
    $('.cB, .csendingtwo, .isversiontotwo').hover(function(){
        $('.csendingtwo, .isversiontotwo').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingtwo, .isversiontotwo').css("background-color", "#425563").css("color", "white");
    });
}); 
        
        


        

<!-- Third column -->
        
                                $(document).ready(function(){
    $('.cC, .csendingthree, .isversiontothree').hover(function(){
        $('.csendingthree, .isversiontothree').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingthree, .isversiontothree').css("background-color", "#425563").css("color", "white");
    });
}); 
        
        
 

<!-- Forth column cD csendingfour isversiontofour-->
        
                                $(document).ready(function(){
    $('.cD, .csendingfour, .isversiontofour').hover(function(){
        $('.csendingfour, .isversiontofour').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingfour, .isversiontofour').css("background-color", "#425563").css("color", "white");
    });
}); 
        
 
    
 <!-- Fifth column (E) -->
                                $(document).ready(function(){
    $('.cE, .csendingfive, .isversiontofive').hover(function(){
        $('.csendingfive, .isversiontofive').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingfive, .isversiontofive').css("background-color", "#425563").css("color", "white");
    });
}); 
        
  
    
 <!-- Six column (F) -->       
                                $(document).ready(function(){
    $('.cF, .csendingsix, .isversiontosix').hover(function(){
        $('.csendingsix, .isversiontosix').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingsix, .isversiontosix').css("background-color", "#425563").css("color", "white");
    });
}); 
        


 <!-- Seventh column (G) -->         

                                $(document).ready(function(){
    $('.cG, .csendingseven, .isversiontoseven').hover(function(){
        $('.csendingseven, .isversiontoseven').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingseven, .isversiontoseven').css("background-color", "#425563").css("color", "white");
    });
}); 
        
        
    
    
 <!-- Eighth column (H) -->        
                                $(document).ready(function(){
    $('.cH, .csendingeight, .isversiontoeight').hover(function(){
        $('.csendingeight, .isversiontoeight').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingeight, .isversiontoeight').css("background-color", "#425563").css("color", "white");
    });
}); 
        
        
   
  <!-- Ninth column (I) -->        
                                $(document).ready(function(){
    $('.cI, .csendingnine, .isversiontonine').hover(function(){
        $('.csendingnine, .isversiontonine').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingnine, .isversiontonine').css("background-color", "#425563").css("color", "white");
    });
}); 
        
        
 
  <!-- Tenth column (J) -->       
                                $(document).ready(function(){
    $('.cJ, .csendingten, .isversiontoten').hover(function(){
        $('.csendingten, .isversiontoten').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingten, .isversiontoten').css("background-color", "#425563").css("color", "white");
    });
}); 
        
   <!-- Eleventh column (J) -->       
                                $(document).ready(function(){
    $('.cK, .csendingeleven, .isversiontoeleven').hover(function(){
        $('.csendingeleven, .isversiontoeleven').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingeleven, .isversiontoeleven').css("background-color", "#425563").css("color", "white");
    });
}); 

   <!-- Twleve column (J) -->       
                                $(document).ready(function(){
    $('.cM, .csendingfourteen, .isversiontotwelve').hover(function(){
        $('.csendingfourteen, .isversiontotwelve').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingfourteen, .isversiontotwelve').css("background-color", "#425563").css("color", "white");
    });
}); 
       
        
       <!-- Thirteenth column (J) -->       
                                $(document).ready(function(){
    $('.cN, .csendingthirteen, .isversiontothirteen').hover(function(){
        $('.csendingthirteen, .isversiontothirteen').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingthirteen, .isversiontothirteen').css("background-color", "#425563").css("color", "white");
    });
}); 
  
       <!-- Fourteenth column (J) -->       
                                $(document).ready(function(){
    $('.cL, .csendingfourteen, .isversiontofourteen').hover(function(){
        $('.csendingfourteen, .isversiontofourteen').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingfourteen, .isversiontofourteen').css("background-color", "#425563").css("color", "white");
    });



   $('.cN, .csendingfifteen, .isversiontofifteen').hover(function(){
        $('.csendingfifteen, .isversiontofifteen').css("background-color", "#252a2e").css("color", "white");
        }, function(){
        $('.csendingfifteen, .isversiontofifteen').css("background-color", "#425563").css("color", "white");
    });
}); 
  